// Auth config disabled for supply chain optimization app
export default {
  providers: [],
};
