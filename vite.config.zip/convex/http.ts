// HTTP routes for supply chain optimization (no auth required)
import router from "./router";

const http = router;

export default http;
