import React, { useState, useCallback } from 'react';
import { Toaster } from 'sonner';
import { useQuery } from 'convex/react';
import { api } from '../convex/_generated/api';
import FileUpload from './components/FileUpload';
import Dashboard from './components/Dashboard';
import ScenarioPanel from './components/ScenarioPanel';
import { SupplyChainData, OptimizationResults, ScenarioResult } from './types';

export default function App() {
  const [loading, setLoading] = useState(false);
  const [scenarioResults, setScenarioResults] = useState<ScenarioResult[]>([]);

  // Get data from Convex (no auth required)
  const dataSummary = useQuery(api.supplyChain.getDataSummary);
  const optimizationResults = useQuery(api.supplyChain.getOptimizationResults);
  const savedScenarioResults = useQuery(api.supplyChain.getScenarioResults);

  const handleDataUpload = useCallback((uploadedData: SupplyChainData, uploadedResults: OptimizationResults) => {
    setScenarioResults([]); // Clear previous scenarios
  }, []);

  const handleScenarioRun = useCallback((scenarioResult: ScenarioResult) => {
    setScenarioResults(prev => [...prev, scenarioResult]);
  }, []);

  // Combine local and saved scenario results
  const allScenarioResults: ScenarioResult[] = [
    ...scenarioResults,
    ...(savedScenarioResults || []).map(sr => ({
      scenarioName: sr.scenarioName,
      results: sr.results as ScenarioResult['results'],
      timestamp: sr.timestamp,
    }))
  ];

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#ECF0F1' }}>
      <header className="bg-white shadow-sm border-b" style={{ borderColor: '#2C3E50' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div>
              <h1 className="text-2xl font-bold" style={{ color: '#2C3E50' }}>
                Supply Chain Optimization Platform
              </h1>
              <p className="text-base mt-1" style={{ color: '#2C3E50' }}>
                Advanced Analytics for Warehouse Allocation & Vehicle Routing
              </p>
            </div>
            {dataSummary && (
              <div className="text-sm" style={{ color: '#2C3E50' }}>
                <div className="bg-white rounded-lg shadow-sm border px-3 py-2">
                  <span className="font-medium">{dataSummary.locations_count}</span> locations •{' '}
                  <span className="font-medium">{dataSummary.warehouses_count}</span> warehouses •{' '}
                  <span className="font-medium">{dataSummary.stores_count}</span> stores
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {!dataSummary || dataSummary.locations_count === 0 ? (
          <div className="max-w-2xl mx-auto">
            <FileUpload onDataUpload={handleDataUpload} loading={loading} setLoading={setLoading} />
          </div>
        ) : (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              <div className="lg:col-span-3">
                <Dashboard 
                  data={dataSummary} 
                  results={optimizationResults || null} 
                  scenarioResults={allScenarioResults}
                />
              </div>
              <div className="lg:col-span-1">
                <ScenarioPanel 
                  data={dataSummary} 
                  onScenarioRun={handleScenarioRun}
                  loading={loading}
                  setLoading={setLoading}
                />
              </div>
            </div>
          </div>
        )}
      </main>

      <Toaster position="top-right" />
    </div>
  );
}
