import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileText } from 'lucide-react';
import { toast } from 'sonner';
import { useAction, useMutation } from 'convex/react';
import { api } from '../../convex/_generated/api';
import { SupplyChainData, OptimizationResults } from '../types';

interface FileUploadProps {
  onDataUpload: (data: SupplyChainData, results: OptimizationResults) => void;
  loading: boolean;
  setLoading: (loading: boolean) => void;
}

export default function FileUpload({ onDataUpload, loading, setLoading }: FileUploadProps) {
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  
  const processFiles = useAction(api.supplyChain.processUploadedFiles);
  const generateUploadUrl = useMutation(api.supplyChain.generateUploadUrl);
  const loadSampleData = useAction(api.supplyChain.loadSampleData);

  const handleLoadSampleData = async () => {
    setLoading(true);
    
    try {
      // Load sample data and generate optimization results
      const results = await loadSampleData();
      
      const sampleDataSummary = {
        locations_count: 8,
        warehouses_count: 3,
        stores_count: 5,
        capacity_records: 3,
        demand_records: 5,
      };
      
      toast.success('Sample supply chain data loaded successfully!');
      onDataUpload(sampleDataSummary, results);
      
    } catch (error) {
      console.error('Sample data error:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to load sample data');
    } finally {
      setLoading(false);
    }
  };

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const excelFiles = acceptedFiles.filter(file => 
      file.name.endsWith('.xlsx') || file.name.endsWith('.xls')
    );
    
    if (excelFiles.length !== acceptedFiles.length) {
      toast.error('Please upload only Excel files (.xlsx or .xls)');
      return;
    }

    setUploadedFiles(prev => [...prev, ...excelFiles]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.ms-excel': ['.xls']
    },
    multiple: true
  });

  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleUpload = async () => {
    if (uploadedFiles.length === 0) {
      toast.error('Please select files to upload');
      return;
    }

    setLoading(true);
    
    try {
      const uploadResults = [];
      
      // Upload each file to Convex storage
      for (const file of uploadedFiles) {
        // Convert File to ArrayBuffer then to Blob
        const arrayBuffer = await file.arrayBuffer();
        const blob = new Blob([arrayBuffer], { type: file.type });
        
        // Generate upload URL using Convex mutation
        const uploadUrl = await generateUploadUrl();
        
        // Upload file
        const uploadResponse = await fetch(uploadUrl, {
          method: 'POST',
          headers: { 'Content-Type': file.type },
          body: blob,
        });
        
        if (!uploadResponse.ok) {
          throw new Error(`Failed to upload ${file.name}`);
        }
        
        const { storageId } = await uploadResponse.json();
        
        uploadResults.push({
          fileName: file.name,
          fileId: storageId, // Use storageId as fileId for now
          storageId,
        });
      }

      // Process the uploaded files
      const result = await processFiles({ uploadResults });
      
      toast.success('Files uploaded and processed successfully!');
      onDataUpload(result.dataSummary, result.results);
      setUploadedFiles([]);
      
    } catch (error) {
      console.error('Upload error:', error);
      toast.error(error instanceof Error ? error.message : 'Upload failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg border-2 p-6" style={{ borderColor: '#2C3E50' }}>
      <div className="text-center mb-6">
        <div className="p-3 rounded-full inline-block mb-3" style={{ backgroundColor: '#ECF0F1' }}>
          <Upload className="h-12 w-12" style={{ color: '#2C3E50' }} />
        </div>
        <h2 className="text-2xl font-bold mb-3" style={{ color: '#2C3E50' }}>
          Upload Supply Chain Data
        </h2>
        <p className="text-base" style={{ color: '#2C3E50' }}>
          Upload Excel files to begin optimization analysis
        </p>
      </div>

      <div
        {...getRootProps()}
        className={`border-3 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all duration-300 ${
          isDragActive
            ? 'border-opacity-100 bg-opacity-10'
            : 'border-opacity-50 hover:border-opacity-75'
        }`}
        style={{ 
          borderColor: isDragActive ? '#16A085' : '#2C3E50',
          backgroundColor: isDragActive ? '#16A085' : 'transparent'
        }}
      >
        <input {...getInputProps()} />
        <FileText className="mx-auto h-10 w-10 mb-3" style={{ color: '#2C3E50' }} />
        {isDragActive ? (
          <p className="text-lg font-medium" style={{ color: '#16A085' }}>
            Drop the Excel files here...
          </p>
        ) : (
          <div>
            <p className="text-lg font-medium mb-2" style={{ color: '#2C3E50' }}>
              Drag & drop Excel files here, or click to select
            </p>
            <p className="text-sm" style={{ color: '#2C3E50' }}>
              Supports .xlsx and .xls files
            </p>
          </div>
        )}
      </div>

      {uploadedFiles.length > 0 && (
        <div className="mt-6">
          <h3 className="text-lg font-bold mb-3" style={{ color: '#2C3E50' }}>
            Selected Files ({uploadedFiles.length})
          </h3>
          <div className="space-y-2">
            {uploadedFiles.map((file, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 rounded-lg border"
                style={{ backgroundColor: '#ECF0F1', borderColor: '#2C3E50' }}
              >
                <div className="flex items-center">
                  <FileText className="h-4 w-4 mr-3" style={{ color: '#2C3E50' }} />
                  <div>
                    <span className="font-medium text-sm" style={{ color: '#2C3E50' }}>{file.name}</span>
                    <span className="text-xs ml-2" style={{ color: '#2C3E50' }}>
                      ({(file.size / 1024).toFixed(1)} KB)
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => removeFile(index)}
                  className="px-2 py-1 rounded text-sm font-medium hover:opacity-80 transition-opacity"
                  style={{ backgroundColor: '#C0392B', color: 'white' }}
                >
                  Remove
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="flex gap-3 mt-6">
        <button
          onClick={handleUpload}
          disabled={uploadedFiles.length === 0 || loading}
          className="flex-1 py-3 px-4 rounded-lg text-base font-bold transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
          style={{ 
            backgroundColor: uploadedFiles.length === 0 || loading ? '#95A5A6' : '#E67E22',
            color: 'white'
          }}
        >
          {loading ? (
            <div className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              Processing...
            </div>
          ) : (
            'Upload & Process Files'
          )}
        </button>
        
        <button
          onClick={handleLoadSampleData}
          disabled={loading}
          className="px-4 py-3 rounded-lg text-base font-bold transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
          style={{ 
            backgroundColor: loading ? '#95A5A6' : '#16A085',
            color: 'white'
          }}
        >
          {loading ? 'Loading...' : 'Try Demo'}
        </button>
      </div>
    </div>
  );
}
