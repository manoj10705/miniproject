export interface SupplyChainData {
  locations_count: number;
  warehouses_count: number;
  stores_count: number;
  capacity_records?: number;
  demand_records?: number;
}

export interface OptimizationResults {
  demand_forecast: any;
  allocation: any;
  routing: any;
  metrics: any;
}

export interface ScenarioResult {
  scenarioName: string;
  results: {
    scenario_results: {
      total_cost: number;
      capacity_utilization: number;
      demand_fulfillment: number;
    };
  };
  timestamp: number;
}
